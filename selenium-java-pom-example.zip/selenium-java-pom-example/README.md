# selenium-java-pom-example

This example currently supports Linux and Windows, both with Java 8 and above. Maven and Chrome browser are also required.

To run on Windows or Linux, simply clone the repository and from root project diectory run:
```
mvn test
```
